<?php
/**
 * Template Name: Learning & Development Template
 *
 * This template can be used to override the default template and sidebar setup
 *
 * @package Understrap
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

get_header();
$container = get_theme_mod( 'understrap_container_type' );
?>

<div class="wrapper" id="page-wrapper">

	<div class="<?php echo esc_attr( $container ); ?>" id="content">

		<div class="row">
                <div class="page-header-single flex-column">
                    <header class="entry-header">
                        <h1 class="entry-title" data-aos="fade-in" data-aos-delay="500" data-aos-easing="ease-in-out">Learning and Development</h1>
                    </header>
                    <div class="entry-content">
                        <div class="intranet-buttons mt-3" data-aos="fade-in" data-aos-delay="500" data-aos-easing="ease-in-out">
                            <a target="_blank" CLASS="intranet-buttons__btn" href="https://statom.sharepoint.com/sites/STIMS/SitePages/Statom---IMS.aspx">Browse IMS Sharepoint</a>
                        </div>
                    </div>
                </div>

        <main class="site-main" id="main" role="main" data-aos="fade-in" data-aos-delay="500" data-aos-easing="ease-in-out">

                    <div class="intranet-hr-box-wrapper">

                        <div class="row">

                            <div class="col-lg-4 intranet-hr-box-wrapper__box">
                                <div class="intranet-hr-box-wrapper__box-image">
                                    <img src="https://intranet.statomgroup.co.uk/wp-content/uploads/2025/06/thumbnail-4.jpeg">
                                </div>
                                <div class="intranet-hr-box-wrapper__box-content">
                                    <div class="intranet-hr-box-wrapper__overlay-box"></div>
                                    <h4>Course - Standards</h4>
                                    <a target="_blank" href="https://statom.sharepoint.com/sites/STIMS/Shared%20Documents/Forms/AllItems.aspx?id=%2Fsites%2FSTIMS%2FShared%20Documents%2FGeneral%2FSTATOM%20Course%20Standards%2Epdf&viewid=36bc5c83%2D6926%2D4ab4%2Daa2e%2D72ae81ef136a&parent=%2Fsites%2FSTIMS%2FShared%20Documents%2FGeneral">Click Here</a>
                                    </div>
                            </div>

                            <div class="col-lg-4 intranet-hr-box-wrapper__box">
                                <div class="intranet-hr-box-wrapper__box-image">
                                    <img src="https://intranet.statomgroup.co.uk/wp-content/uploads/2025/06/a94199c0-ea53-4793-8084-c00404dc8658.webp">
                                </div>
                                <div class="intranet-hr-box-wrapper__box-content">
                                    <div class="intranet-hr-box-wrapper__overlay-box"></div>
                                    <h4>Training Request Form</h4>
                                    <a target="_blank" href="https://statom.sharepoint.com/:x:/r/sites/STIMS/_layouts/15/Doc.aspx?sourcedoc=%7B35E6C26F-F1D1-4604-AF53-4EC62116CA5A%7D&file=TRA-PRO-002-01%20-%20STATOM%20Training%20Request%20Form%20.xlsx&action=default&mobileredirect=true&wdLOR=c516E4F70-0D30-475A-A390-18BEF66069AE">Click Here</a>
                                    </div>
                            </div>

                            <div class="col-lg-4 intranet-hr-box-wrapper__box">
                                <div class="intranet-hr-box-wrapper__box-image">
                                    <img src="https://intranet.statomgroup.co.uk/wp-content/uploads/2025/06/content.webp">
                                </div>
                                <div class="intranet-hr-box-wrapper__box-content">
                                    <div class="intranet-hr-box-wrapper__overlay-box"></div>
                                    <h4>Chime</h4>
                                    <a target="_blank" href="https://statom.sharepoint.com/sites/STIMS/Shared%20Documents/Forms/AllItems.aspx?sortField=Modified&isAscending=false&id=%2Fsites%2FSTIMS%2FShared%20Documents%2FGeneral%2FHow%20to%20Managers%20Guide%20Desktop%2Epdf&viewid=36bc5c83%2D6926%2D4ab4%2Daa2e%2D72ae81ef136a&parent=%2Fsites%2FSTIMS%2FShared%20Documents%2FGeneral">Click Here</a>
                                    </div>
                            </div>

                            <div class="col-lg-4 intranet-hr-box-wrapper__box">
                                <div class="intranet-hr-box-wrapper__box-image">
                                    <img src="https://intranet.statomgroup.co.uk/wp-content/uploads/2025/06/content-6.webp">
                                </div>
                                <div class="intranet-hr-box-wrapper__box-content">
                                    <div class="intranet-hr-box-wrapper__overlay-box"></div>
                                    <h4>Frames & Civils - Training Standard</h4>
                                    <a target="_blank" href="https://statom.sharepoint.com/:x:/r/sites/STIMS/_layouts/15/Doc.aspx?sourcedoc=%7B6115128C-A8B9-4A5E-AA7E-0F3873B38C67%7D&file=TRN-MNL-011-01%20-Training%20Matrix%20-%20SLIPFORM.xlsx&action=default&mobileredirect=true&wdLOR=cFD6E4184-B792-4780-BB73-54B8395658E9">Click Here</a>
                                    </div>
                            </div>

                            <div class="col-lg-4 intranet-hr-box-wrapper__box">
                                <div class="intranet-hr-box-wrapper__box-image">
                                    <img src="https://intranet.statomgroup.co.uk/wp-content/uploads/2025/06/content-3.webp">
                                </div>
                                <div class="intranet-hr-box-wrapper__box-content">
                                    <div class="intranet-hr-box-wrapper__overlay-box"></div>
                                    <h4>Slipform - Training Standard</h4>
                                    <a target="_blank" href="https://statom.sharepoint.com/:x:/r/sites/STIMS/_layouts/15/Doc.aspx?sourcedoc=%7B6115128C-A8B9-4A5E-AA7E-0F3873B38C67%7D&file=TRN-MNL-011-01%20-Training%20Matrix%20-%20SLIPFORM.xlsx&action=default&mobileredirect=true&wdLOR=cFD6E4184-B792-4780-BB73-54B8395658E9">Click Here</a>
                                    </div>
                            </div>

                            <div class="col-lg-4 intranet-hr-box-wrapper__box">
                                <div class="intranet-hr-box-wrapper__box-image">
                                    <img src="https://intranet.statomgroup.co.uk/wp-content/uploads/2025/06/ec2ebd5e-8a38-45b6-94e3-673dbe9453b1.webp">
                                </div>
                                <div class="intranet-hr-box-wrapper__box-content">
                                    <div class="intranet-hr-box-wrapper__overlay-box"></div>
                                    <h4>Groundworks - Training Standard</h4>
                                    <a target="_blank" href="https://statom.sharepoint.com/:x:/r/sites/STIMS/_layouts/15/Doc.aspx?sourcedoc=%7B06CF60D7-21BC-4016-A2D1-B5E1C5CFF4CD%7D&file=TRN-MNL-008-01%20-STATOM%20Training%20Standards%20-%20Groundwork.xlsx&action=default&mobileredirect=true&wdLOR=cAAFB044F-95BA-42FF-8E13-0633B58F6D9B">Click Here</a>
                                    </div>
                            </div>

                             <div class="col-lg-4 intranet-hr-box-wrapper__box">
                                <div class="intranet-hr-box-wrapper__box-image">
                                    <img src="https://intranet.statomgroup.co.uk/wp-content/uploads/2025/06/content-5.webp">
                                </div>
                                <div class="intranet-hr-box-wrapper__box-content">
                                    <div class="intranet-hr-box-wrapper__overlay-box"></div>
                                    <h4>Demolition - Training Standard</h4>
                                    <a target="_blank" href="https://statom.sharepoint.com/:x:/r/sites/STIMS/_layouts/15/Doc.aspx?sourcedoc=%7BD6072B62-26A6-467E-BF98-0E7BEFA6C693%7D&file=STATOM%20Training%20Standards%20-%20DEMO.xlsx&action=default&mobileredirect=true&wdLOR=c8A4082C4-B44D-4864-8536-53E735517817">Click Here</a>
                                    </div>
                            </div>

                            <div class="col-lg-4 intranet-hr-box-wrapper__box">
                                <div class="intranet-hr-box-wrapper__box-image">
                                    <img src="https://intranet.statomgroup.co.uk/wp-content/uploads/2025/06/content-4.webp">
                                </div>
                                <div class="intranet-hr-box-wrapper__box-content">
                                    <div class="intranet-hr-box-wrapper__overlay-box"></div>
                                    <h4>Commercial - Training Standard</h4>
                                    <a target="_blank" href="https://statom.sharepoint.com/:x:/r/sites/STIMS/_layouts/15/Doc.aspx?sourcedoc=%7B58FFD9FA-594E-4624-974C-DB916069C812%7D&file=TRN-MNL-010-01%20-STATOM%20Training%20Standards%20-%20Commercial.xlsx&action=default&mobileredirect=true&wdLOR=cEE1D75AB-F68C-4B12-8395-141BE33EF0BA">Click Here</a>
                                    </div>
                            </div>

                        </div>
                    </div>
				</main>

			</div><!-- #primary -->


		</div><!-- .row -->

	</div><!-- #content -->

</div><!-- #page-wrapper -->

<?php
get_footer();
