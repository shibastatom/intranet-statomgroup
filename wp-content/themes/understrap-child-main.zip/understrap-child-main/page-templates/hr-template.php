<?php
/**
 * Template Name: Human Resources Template
 *
 * This template can be used to override the default template and sidebar setup
 *
 * @package Understrap
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

get_header();
$container = get_theme_mod( 'understrap_container_type' );
?>

<div class="wrapper" id="page-wrapper">

	<div class="<?php echo esc_attr( $container ); ?>" id="content">

		<div class="row">
                <div class="page-header-single flex-column">
                    <header class="entry-header">
                        <h1 class="entry-title" data-aos="fade-in" data-aos-delay="500" data-aos-easing="ease-in-out">My Employment</h1>
                    </header>
                    <div class="entry-content">
                        <div class="intranet-buttons mt-3" data-aos="fade-in" data-aos-delay="500" data-aos-easing="ease-in-out">
                            <a target="_blank" CLASS="intranet-buttons__btn" href="https://statom.sharepoint.com/sites/STIMS/SitePages/Statom---IMS.aspx">Browse IMS Sharepoint</a>
                        </div>
                    </div>
                </div>

        <main class="site-main" id="main" role="main" data-aos="fade-in" data-aos-delay="500" data-aos-easing="ease-in-out">

                    <div class="intranet-hr-box-wrapper">

                        <div class="row">

                            <div class="col-lg-4 intranet-hr-box-wrapper__box">
                                <div class="intranet-hr-box-wrapper__box-image">
                                    <img src="https://intranet.statomgroup.co.uk/wp-content/uploads/2025/06/policies-1.jpg">
                                </div>
                                <div class="intranet-hr-box-wrapper__box-content">
                                    <div class="intranet-hr-box-wrapper__overlay-box"></div>
                                    <h4>Policies & Procedures</h4>
                                    <a target="_blank" href="https://statom.sharepoint.com/sites/STIMS/Shared%20Documents/Forms/AllItems.aspx?csf=1&web=1&e=aHig5T&CID=fc3d50a5%2Db58e%2D4653%2Dabad%2Defc523ac921c&FolderCTID=0x01200077A5455EE3957245B24A9933FC9374C8&id=%2Fsites%2FSTIMS%2FShared%20Documents%2FGeneral%2FPOL%20%2D%20Policies%20%26%20Procedures%20%20%2D%2003%2E10%2E24">Click Here</a>
                                    </div>
                                </div>

                            <div class="col-lg-4 intranet-hr-box-wrapper__box">
                                <div class="intranet-hr-box-wrapper__box-image">
                                    <img src="https://intranet.statomgroup.co.uk/wp-content/uploads/2025/06/booking-time-off-1.jpg">
                                </div>
                                <div class="intranet-hr-box-wrapper__box-content">
                                    <div class="intranet-hr-box-wrapper__overlay-box"></div>
                                    <h4>Booking Time Off</h4>
                                    <a target="_blank" href="https://login.breathehr.com/login?redirect_app=hr">Click Here</a>
                                    </div>
                                </div>

                            <div class="col-lg-4 intranet-hr-box-wrapper__box">
                                <div class="intranet-hr-box-wrapper__box-image">
                                    <img src="https://intranet.statomgroup.co.uk/wp-content/uploads/2025/06/code-of-conduct-1.jpg">
                                </div>
                                <div class="intranet-hr-box-wrapper__box-content">
                                    <div class="intranet-hr-box-wrapper__overlay-box"></div>
                                    <h4>Code of Conduct</h4>
                                    <a target="_blank" href="https://statom.sharepoint.com/sites/STIMS/Shared%20Documents/Forms/AllItems.aspx?id=%2Fsites%2FSTIMS%2FShared%20Documents%2FGeneral%2FStatom%20Group%20Ltd%2E%20%2D%20Code%20of%20Conduct%2Epdf&viewid=36bc5c83%2D6926%2D4ab4%2Daa2e%2D72ae81ef136a&parent=%2Fsites%2FSTIMS%2FShared%20Documents%2FGeneral">Click Here</a>
                                    </div>
                                </div>

                            <div class="col-lg-4 intranet-hr-box-wrapper__box">
                                <div class="intranet-hr-box-wrapper__box-image">
                                    <img src="https://intranet.statomgroup.co.uk/wp-content/uploads/2025/06/review-form-scaled-1.jpg">
                                </div>
                                <div class="intranet-hr-box-wrapper__box-content">
                                    <div class="intranet-hr-box-wrapper__overlay-box"></div>
                                    <h4>3 Month - Review Form</h4>
                                    <a target="_blank" href="https://statom.sharepoint.com/:w:/r/sites/STIMS/_layouts/15/Doc.aspx?sourcedoc=%7BD7D7CAD9-03DB-4056-8D6E-6546F008647E%7D&file=Three%20Month%20Review_FORM.docx&action=default&mobileredirect=true">Click Here</a>
                                    </div>
                                </div>

                            <div class="col-lg-4 intranet-hr-box-wrapper__box">
                                <div class="intranet-hr-box-wrapper__box-image">
                                    <img src="https://intranet.statomgroup.co.uk/wp-content/uploads/2025/06/it-1.jpg">
                                </div>
                                <div class="intranet-hr-box-wrapper__box-content">
                                    <div class="intranet-hr-box-wrapper__overlay-box"></div>
                                    <h4>IT Equipment Requisition</h4>
                                    <a target="_blank" href="https://statom.sharepoint.com/:w:/r/sites/STIMS/_layouts/15/Doc.aspx?sourcedoc=%7B54AFF9F4-9638-4333-883F-A633C6111253%7D&file=COM-CHK-002-01%20-%20IT%20Requisition%20Form%202024.docx&action=default&mobileredirect=true&wdLOR=cC7CBA63C-8A2C-4C17-B2A5-7AD9C63287E2">Click Here</a>
                                    </div>
                                </div>

                            <div class="col-lg-4 intranet-hr-box-wrapper__box">
                                <div class="intranet-hr-box-wrapper__box-image">
                                    <img src="https://intranet.statomgroup.co.uk/wp-content/uploads/2025/06/claim-form-1.jpg">
                                </div>
                                <div class="intranet-hr-box-wrapper__box-content">
                                    <div class="intranet-hr-box-wrapper__overlay-box"></div>
                                    <h4>Claim Form - Expenses</h4>
                                    <a target="_blank" href="https://statom.sharepoint.com/:x:/r/sites/STIMS/_layouts/15/Doc.aspx?sourcedoc=%7BB0C4DBA3-61A8-4967-8DD3-6575276E32E6%7D&file=STATOM%20Expense%20form.xlsx&action=default&mobileredirect=true&wdLOR=c7D2A0017-61C7-4D18-8590-F4FD9E1C3745">Click Here</a>
                                    </div>
                                </div>

                         

                            <div class="col-lg-4 intranet-hr-box-wrapper__box">
                                <div class="intranet-hr-box-wrapper__box-image">
                                    <img src="https://intranet.statomgroup.co.uk/wp-content/uploads/2025/06/agreement-1.jpg">
                                </div>
                                <div class="intranet-hr-box-wrapper__box-content">
                                    <div class="intranet-hr-box-wrapper__overlay-box"></div>
                                    <h4>Subcontractor Training Agreement</h4>
                                    <a target="_blank" href="https://statom.sharepoint.com/:w:/r/sites/STIMS/_layouts/15/Doc.aspx?sourcedoc=%7BF8F8B5C9-989E-419C-B511-95FF129B7259%7D&file=SUBCONTRACTOR%20TRAINING%20AGREEMENT.docx&action=default&mobileredirect=true">Click Here</a>
                                    </div>
                                </div>

                            <div class="col-lg-4 intranet-hr-box-wrapper__box">
                                <div class="intranet-hr-box-wrapper__box-image">
                                    <img src="https://intranet.statomgroup.co.uk/wp-content/uploads/2025/06/expression-of-wish-1.jpg">
                                </div>
                                <div class="intranet-hr-box-wrapper__box-content">
                                    <div class="intranet-hr-box-wrapper__overlay-box"></div>
                                    <h4>Expressions of Wishes</h4>
                                    <a target="_blank" href="https://statom.sharepoint.com/sites/STIMS/Shared%20Documents/Forms/AllItems.aspx?id=%2Fsites%2FSTIMS%2FShared%20Documents%2FGeneral%2FStatom%20%2D%20Expression%2Dof%2DWish%2Dform%2Epdf&viewid=36bc5c83%2D6926%2D4ab4%2Daa2e%2D72ae81ef136a&parent=%2Fsites%2FSTIMS%2FShared%20Documents%2FGeneral">Click Here</a>
                                    </div>
                                </div>

                            <div class="col-lg-4 intranet-hr-box-wrapper__box">
                                <div class="intranet-hr-box-wrapper__box-image">
                                    <img src="https://intranet.statomgroup.co.uk/wp-content/uploads/2025/06/employee-handbook-1.jpg">
                                </div>
                                <div class="intranet-hr-box-wrapper__box-content">
                                    <div class="intranet-hr-box-wrapper__overlay-box"></div>
                                    <h4>Employee Handbook</h4>
                                    <a target="_blank" href="https://statom.sharepoint.com/sites/STIMS/Shared%20Documents/Forms/AllItems.aspx?id=%2Fsites%2FSTIMS%2FShared%20Documents%2FGeneral%2FEmployee%20Handbook%202025%2Epdf&viewid=36bc5c83%2D6926%2D4ab4%2Daa2e%2D72ae81ef136a&parent=%2Fsites%2FSTIMS%2FShared%20Documents%2FGeneral">Click Here</a>
                                    </div>
                            </div>

                            <div class="col-lg-4 intranet-hr-box-wrapper__box">
                                <div class="intranet-hr-box-wrapper__box-image">
                                    <img src="https://intranet.statomgroup.co.uk/wp-content/uploads/2025/06/assessment-1.jpg">
                                </div>
                                <div class="intranet-hr-box-wrapper__box-content">
                                    <div class="intranet-hr-box-wrapper__overlay-box"></div>
                                    <h4>DSE Assessment</h4>
                                    <a target="_blank" href="https://statom.sharepoint.com/:w:/r/sites/STIMS/_layouts/15/Doc.aspx?sourcedoc=%7B71C0798F-D0DB-4C70-8EA2-916AD7CF4C21%7D&file=SAF-FRM-061-01%20-%20DSE%20Assessment.docx&action=default&mobileredirect=true">Click Here</a>
                                    </div>
                            </div>
                            
                             <div class="col-lg-4 intranet-hr-box-wrapper__box">
                                <div class="intranet-hr-box-wrapper__box-image">
                                    <img src="https://intranet.statomgroup.co.uk/wp-content/uploads/2025/07/screen-assessment.jpg">
                                </div>
                                <div class="intranet-hr-box-wrapper__box-content">
                                    <div class="intranet-hr-box-wrapper__overlay-box"></div>
                                    <h4>Display Screen Assessment</h4>
                                    <a target="_blank" href="https://statom.sharepoint.com/:w:/r/sites/STIMS/_layouts/15/Doc.aspx?sourcedoc=%7B71C0798F-D0DB-4C70-8EA2-916AD7CF4C21%7D&file=SAF-FRM-061-01%20-%20DSE%20Assessment.docx&action=default&mobileredirect=true">Click Here</a>
                                    </div>
                            </div>
                        </div>
                    </div>

				</main>

			</div><!-- #primary -->


		</div><!-- .row -->

	</div><!-- #content -->

</div><!-- #page-wrapper -->

<?php
get_footer();
