<?php
/**
 * Template Name: Employee Benefits Template
 *
 * This template can be used to override the default template and sidebar setup
 *
 * @package Understrap
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

get_header();
$container = get_theme_mod( 'understrap_container_type' );
?>

<div class="wrapper" id="page-wrapper">

	<div class="<?php echo esc_attr( $container ); ?>" id="content">

		<div class="row">
                <div class="page-header-single flex-column">
                    <header class="entry-header">
                        <h1 class="entry-title" data-aos="fade-in" data-aos-delay="500" data-aos-easing="ease-in-out">Employee Benefits</h1>
                    </header>
                    <div class="entry-content">
                        <div class="intranet-buttons mt-3" data-aos="fade-in" data-aos-delay="500" data-aos-easing="ease-in-out">
                            <a target="_blank" CLASS="intranet-buttons__btn" href="https://statom.sharepoint.com/sites/STIMS/SitePages/Statom---IMS.aspx">Browse IMS Sharepoint</a>
                        </div>
                    </div>
                </div>

        <main class="site-main" id="main" role="main" data-aos="fade-in" data-aos-delay="500" data-aos-easing="ease-in-out">

                    <div class="intranet-hr-box-wrapper">

                        <div class="row">

                            <div class="col-lg-4 intranet-hr-box-wrapper__box">
                                <div class="intranet-hr-box-wrapper__box-image">
                                    <img src="https://intranet.statomgroup.co.uk/wp-content/uploads/2025/06/thumbnail-10.jpeg">
                                </div>
                                <div class="intranet-hr-box-wrapper__box-content">
                                    <div class="intranet-hr-box-wrapper__overlay-box"></div>
                                    <h4>Private Medical Insurance</h4>
                                    <a target="_blank" href="https://statom.sharepoint.com/sites/STIMS/Shared%20Documents/Forms/AllItems.aspx?id=%2Fsites%2FSTIMS%2FShared%20Documents%2FGeneral%2FStatom%20Private%20Medical%20Insurance%2006%2E06%2E2025%2Epdf&viewid=36bc5c83%2D6926%2D4ab4%2Daa2e%2D72ae81ef136a&parent=%2Fsites%2FSTIMS%2FShared%20Documents%2FGeneral">Click Here</a>
                                </div>
                            </div>

                            <div class="col-lg-4 intranet-hr-box-wrapper__box">
                                <div class="intranet-hr-box-wrapper__box-image">
                                    <img src="https://intranet.statomgroup.co.uk/wp-content/uploads/2025/06/thumbnail-13.jpeg">
                                </div>
                                <div class="intranet-hr-box-wrapper__box-content">
                                    <div class="intranet-hr-box-wrapper__overlay-box"></div>
                                    <h4>Employee Life Insurance</h4>
                                    <a target="_blank" href="https://statom.sharepoint.com/sites/STIMS/Shared%20Documents/Forms/AllItems.aspx?sortField=Modified&isAscending=false&id=%2Fsites%2FSTIMS%2FShared%20Documents%2FGeneral%2FEmployee%20Life%20Insurance%20Cover%2015%2E01%2E2025%2Epdf&viewid=36bc5c83%2D6926%2D4ab4%2Daa2e%2D72ae81ef136a&parent=%2Fsites%2FSTIMS%2FShared%20Documents%2FGeneral">Click Here</a>
                                </div>
                            </div>

                    

                            <div class="col-lg-4 intranet-hr-box-wrapper__box">
                                <div class="intranet-hr-box-wrapper__box-image">
                                    <img src="https://intranet.statomgroup.co.uk/wp-content/uploads/2025/06/musculoskeletal-plan.webp">
                                </div>
                                <div class="intranet-hr-box-wrapper__box-content">
                                    <div class="intranet-hr-box-wrapper__overlay-box"></div>
                                    <h4>Musculoskeletal Pain  - No GP referral</h4>
                                    <a target="_blank" href="https://statom.sharepoint.com/sites/STIMS/Shared%20Documents/Forms/AllItems.aspx?id=%2Fsites%2FSTIMS%2FShared%20Documents%2FGeneral%2FStatom%20%2DMusculoskeletal%20Pain%20%2D%20No%20need%20for%20GP%20Referal%2Epdf&viewid=36bc5c83%2D6926%2D4ab4%2Daa2e%2D72ae81ef136a&parent=%2Fsites%2FSTIMS%2FShared%20Documents%2FGeneral">Click Here</a>
                                </div>
                            </div>

                            <div class="col-lg-4 intranet-hr-box-wrapper__box">
                                <div class="intranet-hr-box-wrapper__box-image">
                                    <img src="https://intranet.statomgroup.co.uk/wp-content/uploads/2025/06/content-2.webp">
                                </div>
                                <div class="intranet-hr-box-wrapper__box-content">
                                    <div class="intranet-hr-box-wrapper__overlay-box"></div>
                                    <h4>Protecting your Mental Health</h4>
                                    <a target="_blank" href="https://statom.sharepoint.com/sites/STIMS/Shared%20Documents/Forms/AllItems.aspx?id=%2Fsites%2FSTIMS%2FShared%20Documents%2FGeneral%2FStatom%20%2DMental%20Health%20Pathways%20%2D%20Protecting%20and%20Supporting%20Your%20Mental%20Health%2Epdf&viewid=36bc5c83%2D6926%2D4ab4%2Daa2e%2D72ae81ef136a&parent=%2Fsites%2FSTIMS%2FShared%20Documents%2FGeneral">Click Here</a>
                                </div>
                            </div>

                            <div class="col-lg-4 intranet-hr-box-wrapper__box">
                                <div class="intranet-hr-box-wrapper__box-image">
                                    <img src="https://intranet.statomgroup.co.uk/wp-content/uploads/2025/06/content-1.webp">
                                </div>
                                <div class="intranet-hr-box-wrapper__box-content">
                                    <div class="intranet-hr-box-wrapper__overlay-box"></div>
                                    <h4>Wellbeing Support</h4>
                                    <a target="_blank" href="https://statom.sharepoint.com/sites/STIMS/Shared%20Documents/Forms/AllItems.aspx?sortField=Modified&isAscending=false&id=%2Fsites%2FSTIMS%2FShared%20Documents%2FGeneral%2FStatom%20Group%20Wellbeing%20support%2Epdf&viewid=36bc5c83%2D6926%2D4ab4%2Daa2e%2D72ae81ef136a&parent=%2Fsites%2FSTIMS%2FShared%20Documents%2FGeneral">Click Here</a>
                                </div>
                            </div>

                         

                            <div class="col-lg-4 intranet-hr-box-wrapper__box">
                                <div class="intranet-hr-box-wrapper__box-image">
                                    <img src="https://intranet.statomgroup.co.uk/wp-content/uploads/2025/06/1012522388-scaled-1.jpg">
                                </div>
                                <div class="intranet-hr-box-wrapper__box-content">
                                    <div class="intranet-hr-box-wrapper__overlay-box"></div>
                                    <h4>Specsavers - Employee Guide</h4>
                                    <a target="_blank" href="https://statom.sharepoint.com/sites/STIMS/Shared%20Documents/Forms/AllItems.aspx?sortField=Modified&isAscending=false&id=%2Fsites%2FSTIMS%2FShared%20Documents%2FGeneral%2FStatom%20%2D%20Employee%20Guide%20%2D%20How%20to%20use%20your%20Specsavers%20voucher%2Epdf&viewid=36bc5c83%2D6926%2D4ab4%2Daa2e%2D72ae81ef136a&parent=%2Fsites%2FSTIMS%2FShared%20Documents%2FGeneral">Click Here</a>
                                </div>
                            </div>

                            <div class="col-lg-4 intranet-hr-box-wrapper__box">
                                <div class="intranet-hr-box-wrapper__box-image">
                                    <img src="https://intranet.statomgroup.co.uk/wp-content/uploads/2025/06/1163145791-scaled-1.jpg">
                                </div>
                                <div class="intranet-hr-box-wrapper__box-content">
                                    <div class="intranet-hr-box-wrapper__overlay-box"></div>
                                    <h4>Return to Work Form</h4>
                                    <a target="_blank" href="https://statom.sharepoint.com/:w:/r/sites/STIMS/_layouts/15/Doc.aspx?sourcedoc=%7BEC19CA15-2247-41E2-B350-D21B74D3D5A7%7D&file=Return%20to%20Work%20Form%20-%202025.docx&action=default&mobileredirect=true">Click Here</a>
                                </div>
                            </div>
                         
                        </div>
                    </div>

				</main>

			</div><!-- #primary -->


		</div><!-- .row -->

	</div><!-- #content -->

</div><!-- #page-wrapper -->

<?php
get_footer();
