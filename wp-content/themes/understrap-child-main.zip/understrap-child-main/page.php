<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package Understrap
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

get_header();

$container = get_theme_mod( 'understrap_container_type' );

?>

<div class="wrapper" id="page-wrapper">

	<div class="<?php echo esc_attr( $container ); ?>" id="content" tabindex="-1">

		<div class="row">

			<?php
			// Do the left sidebar check and open div#primary.
			get_template_part( 'global-templates/left-sidebar-check' );
			?>

			<main class="site-main" id="main">

				<div class="page-header-single">
					<?php
						while ( have_posts() ) {
							the_post();
							get_template_part( 'loop-templates/content', 'page' );

							// If comments are open or we have at least one comment, load up the comment template.
							if ( comments_open() || get_comments_number() ) {
								comments_template();
							}
						}
						?>
				</div>

				<div class="intranet-column-grid">
					<iframe src="https://intranet.statomgroup.co.uk/wp-content/uploads/2025/06/Employee-Handbook-2025.pdf" width="100%" height="600px">
					This browser does not support PDFs. Please download the PDF to view it: 
					<a href="https://intranet.statomgroup.co.uk/wp-content/uploads/2025/06/Employee-Handbook-2025.pdf">Download PDF</a>
					</iframe>

					<iframe src="https://intranet.statomgroup.co.uk/wp-content/uploads/2025/06/STATOM-CODE-OF-CONDUCT.pdf" width="100%" height="600px">
					This browser does not support PDFs. Please download the PDF to view it: 
					<a href="https://intranet.statomgroup.co.uk/wp-content/uploads/2025/06/STATOM-CODE-OF-CONDUCT.pdf">Download PDF</a>
					</iframe>
				</div>

				<div class="intranet-document-links">
						<?php if( have_rows('document_links') ): ?>
							<?php while( have_rows('document_links') ): the_row(); ?>	
								
							<a target="_blank" href="<?php the_sub_field('document_link'); ?>">
								<strong><?php the_sub_field('document_label'); ?>
								<div class="download-icon">
									<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M288 32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 242.7-73.4-73.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l128 128c12.5 12.5 32.8 12.5 45.3 0l128-128c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L288 274.7 288 32zM64 352c-35.3 0-64 28.7-64 64l0 32c0 35.3 28.7 64 64 64l384 0c35.3 0 64-28.7 64-64l0-32c0-35.3-28.7-64-64-64l-101.5 0-45.3 45.3c-25 25-65.5 25-90.5 0L165.5 352 64 352zm368 56a24 24 0 1 1 0 48 24 24 0 1 1 0-48z"/></svg>
								</div>
								</strong>
							</a>
						<?php endwhile; endif; ?>
				</div>

			</main>

		</div><!-- .row -->

	</div><!-- #content -->

</div><!-- #page-wrapper -->

<?php
get_footer();
