<?php
/**
 * The template for displaying the front page
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package Understrap
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

get_header();

$container = get_theme_mod( 'understrap_container_type' );

?>

<div class="statom-intranet-actions">
    
   <?php
        date_default_timezone_set('Europe/London'); 
        
        $hour = (int)date('H');
        $greeting = 'Hello';
        
        if ($hour >= 5 && $hour < 12) {
            $greeting = 'Good morning';
        } elseif ($hour >= 12 && $hour < 17) {
            $greeting = 'Good afternoon';
        } elseif ($hour >= 17 && $hour < 22) {
            $greeting = 'Good evening';
        } else {
            $greeting = 'Good night';
        }
        
        ?>
      <div class="container d-flex justify-content-end">
          <div class="greeting-box">
            <?php echo "$greeting!"; ?>
        </div>
      </div>
  
  <div class="slider-css"">

  <div class="statom-intranet-actions__left-actions" data-aos="fade" data-aos-duration="600" data-aos-easing="ease-in-out">
    <div class="statom-slick-slider container">
        <?php
        $args = array(
            'post_type'      => 'post',         
            'posts_per_page' => 5, // Show more than 1 for the slider to work
            'orderby'        => 'date',         
            'order'          => 'DESC'          
        );

        $query = new WP_Query( $args );

        if ( $query->have_posts() ) :
            while ( $query->have_posts() ) : $query->the_post(); ?>
            
                <div class="statom-intranet-actions__news-box">
                    <div class="statom-intranet-actions__featured-image">
                        <?php if ( has_post_thumbnail() ) : ?>
                          <a href="<?php the_permalink(); ?>">  
							<div class="post-thumbnail">
                                <?php the_post_thumbnail('large'); ?>
                            </div>
						</a>
                        <?php endif; ?>
                    </div>

                    <div class="statom-intranet-actions__latest-news">
                        <h3><?php the_title(); ?></h3>
						<p><?php the_excerpt(); ?></p>
                        <a href="<?php the_field('internal_link'); ?>">
                            Read More
                            <div class="statom-intranet-actions__action-icon icon-home">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                                    <path d="M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 144L48 224c-17.7 0-32 14.3-32 32s14.3 32 32 32l144 0 0 144c0 17.7 14.3 32 32 32s32-14.3 32-32l0-144 144 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-144 0 0-144z" />
                                </svg>
                            </div>
                        </a>
                    </div>
                </div>

            <?php endwhile;
            wp_reset_postdata();
        else :
            echo 'No posts found.';
        endif;
        ?>
    </div>
</div>


	<!-- Right Side -->

    <div class="statom-intranet-actions__right-actions" >

	<?php 
if( have_rows('dashboard_buttons') ):
  $delay = 0;
  while( have_rows('dashboard_buttons') ): the_row(); ?>
  
    <a class="statom-intranet-actions__action-box d-flex align-items-center" 
       href="<?php the_sub_field('dashboard_button_link'); ?>" 
       data-aos="fade" 
       data-aos-delay="<?php echo $delay; ?>" 
       data-aos-duration="600"
	   data-aos-easing="ease-in-out">
       
      <div class="statom-intranet-actions__btn">
        <?php the_sub_field('dashboard_button_name'); ?>
        <div class="statom-intranet-actions__action-icon">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
            <path d="M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 144L48 224c-17.7 0-32 14.3-32 32s14.3 32 32 32l144 0 0 144c0 17.7 14.3 32 32 32s32-14.3 32-32l0-144 144 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-144 0 0-144z" />
          </svg>
        </div>
      </div>
    </a>
  
<?php 
    $delay += 150;
  endwhile;
endif;
?>

    </div>
  </div>
</div>


<?php
get_footer();
